========================
Build-time support files
========================

The files contained in this directory are used to support the setup.py
scripts provided in this distribution.  If you just want to install
the software, you don't need to worry about this directory.

The files in this directory are not normally installed.

If you want to pick from components distributed as part of this
distribution, you can install them separately using the setup.py
scripts in the directories under the top-level Dependencies/ directory
(if any).  If you want to separate those components without keeping
this support directory, you can use the setup.py script here to
install the support code on the systems where installation is needed.
