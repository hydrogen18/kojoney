===========================
The Zope Interfaces Package
===========================

This is a separate distribution of the zope.interface package used in
Zope 3, along with the packages it depends on.

This package is a standard distutils package; build it with the command:

    python setup.py build

You can now install it with:

    python setup.py install

You may need to do the later as a priviledged user.

If you have any questions about this package, please read the Zope
Interfaces Wiki:

    http://zope.org/Wikis/Interfaces/FrontPage

New releases can be found at:

    http://zope.org/Products/ZopeInterface/

You can also join the Interface-Dev mailing list and ask there:

    http://mail.zope.org/mailman/listinfo/interface-dev/
