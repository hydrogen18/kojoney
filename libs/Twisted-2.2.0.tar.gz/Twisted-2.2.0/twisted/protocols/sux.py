from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.sux', 'twisted.web.sux',
                         'SAX-like XML parser', 'Web',
                         'http://twistedmatrix.com/projects/web',
                         globals())

