# -*- test-case-name: twisted.pb.test -*-
"""perspective broker tests"""
