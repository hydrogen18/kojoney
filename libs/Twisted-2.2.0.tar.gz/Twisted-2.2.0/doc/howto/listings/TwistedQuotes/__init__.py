"""Twisted Quotes."""
